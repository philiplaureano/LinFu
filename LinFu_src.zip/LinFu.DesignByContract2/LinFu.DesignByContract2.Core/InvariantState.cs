namespace LinFu.DesignByContract2.Core
{
    public enum InvariantState
    {
        BeforeMethodCall = 1,
        AfterMethodCall = 2
    }
}
