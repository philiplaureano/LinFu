using System;
using System.Collections.Generic;
using System.Text;

namespace LinFu.DesignByContract2.Attributes
{
    class DefaultContractStorage
    {
    }
}
