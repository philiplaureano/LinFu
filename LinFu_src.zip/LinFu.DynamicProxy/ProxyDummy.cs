namespace LinFu.DynamicProxy
{
    public class ProxyDummy
    {
        /* No Implementation */
    }
}