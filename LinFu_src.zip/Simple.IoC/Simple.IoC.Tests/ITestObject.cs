using System;
using System.Collections.Generic;
using System.Text;

namespace Simple.IoC.Tests
{
    public interface ITestObject
    {
    }
}
